/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Marks;

import java.util.Scanner;

/**
 *
 * @author 4shr4
 */
public class Grade extends Marks {
    
    //VARIABLES
    private String letterGrade;                                           //We are using this variable with scanner to get grade value which will then determine the mark variable in super class
    
    //METHODS

    public Grade(String nm, int wp) {                           //Passing the type of Mark and how much its weight
        super(nm, wp);
    }
    
    
    public void setLetterGrade(String letterGrade)              //Scanner will be used to alter value of letterGrade string
    {
        this.letterGrade = letterGrade;
    }

    public String getLetterGrade() {                          //After value passed want to return value back
        return letterGrade;
    }
    
    public void changingNumbers(String marks) {
        if (this.letterGrade.equalsIgnoreCase("A")) { super.setMark(0.9);}
        else if (this.letterGrade.equalsIgnoreCase("B")) {super.setMark(0.8);}
        else if (this.letterGrade.equalsIgnoreCase("C")) {super.setMark(0.7);}
        else if (this.letterGrade.equalsIgnoreCase("D")) {super.setMark(0.6);}
        else if (this.letterGrade.equalsIgnoreCase("F")) {super.setMark(0.4);}
        else {super.setMark(0);}
    }

    @Override
    public void readMarks() 
    {
        super.readMarks();
        letterGrade = scan.nextLine();                                                              //Asking for letter Grade
        changingNumbers(letterGrade);                                                           //calling method to get mark from grade
    }
}
