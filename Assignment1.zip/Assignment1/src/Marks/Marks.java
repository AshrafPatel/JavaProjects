/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Marks;

import java.util.Scanner;

/**
 *
 * @author 4shr4
 */
public class Marks {
    
    //VARIABLES
    private double mark;
    Scanner scan = new Scanner(System.in);
    private String name;
    private int weightPercentage;
    
    public Marks(String nm, int wp)                 
    {
        name = nm;
        weightPercentage = wp;
    }
    
    //METHODS
    public double getMark() 
    {
        return mark;                                                //We need to get mark in order to change values for it after entered
    }

    public void setMark(double mark)
    {
        this.mark = mark;                                       //We need to set mark as Scanner object will change values of it
    }

    public int getWeightPercentage()                            //Calling this in MarkList to get weightPercentage for each lab assignment etc.
    {
        return weightPercentage;
    }
    
    public void readMarks()                                                     //Method to calculate grades and ask for input
    {
        System.out.println("Enter the marks for " + name);
    }
}
