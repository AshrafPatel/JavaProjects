/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Marks;

import java.util.Scanner;

/**
 *
 * @author 4shr4
 */
public class Percentage extends Marks {
    
    //VARIABLES
    private double percentage;                                  //This variable will be used to get the percentage which will used in if statement to change super weightPercentage
    
    //METHODS
    public Percentage(String nm, int wp)                    //Using base constructor no additional values needed
    {
        super(nm, wp);
    }
  

    public double getPercentage()                           //After Scanner alters values we need to return values
    {
        return percentage;
    }

    public void setPercentage(double percentage)                    //Scanner will alter values so need a setter
    {
        this.percentage = percentage;
    }
    
     public void changingPercentage(double percentage)                      //PErcentage value will be used to set mark variable in super class
     {
        if (percentage >= 90) { super.setMark(0.9);}
        else if (percentage <= 89 && percentage >= 80) {super.setMark(0.8);}
        else if (percentage <= 79 && percentage >= 70) {super.setMark(0.7);}
        else if (percentage <= 69 && percentage >= 60) {super.setMark(0.6);}
        else if (percentage <= 40) {super.setMark(0.4);}
        else {super.setMark(0);}
    }
     
    @Override
    public void readMarks() 
    {
        super.readMarks();
        percentage = scan.nextDouble();                         //Asking for percentage to calculate into mark
        changingPercentage(percentage);                     //calling method to mark value from percentage
    }
    
}
