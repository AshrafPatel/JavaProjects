/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Marks;

import java.util.Scanner;

/**
 *
 * @author 4shr4
 */
public class MarkList { 
    String name;                                                               //This is a name string which is needed to associate Final grade with said student
    Marks student[];                                                        //This is a Marks Array which is needed to create a MarkList container
    Scanner scan = new Scanner(System.in);
    
    
//    public MarkList()                                                     //Dont really need constructor code as its default values
//    {
//        
//    }
    
//    public MarkList(String name, Marks a[])             //This is manually entering if user doesnt want to use Scanner also great for debugging bu unnecessary atm
//    {
//        this.name = name;
//        this.student = a;
//    }
    
    public void createStudent()                                         
    {
        System.out.println("Please enter students name");       //Each container needs a student name
        name = scan.nextLine();
        
        student = new Marks[4];                                                 //The temp Array is now told it will have 4 containers
        student[0] = new Grade("Lab 1", 20);                                              //The first container will be a grade Object
        student[1] = new Grade("lab 2", 20);
        student[2] = new Grade("Assignment 1", 40);                               
        student[3] = new Percentage("Quiz", 20);                                      //The fourth container will be a Percentage Object
        
        for (Marks student1 : student)
        {
            student1.readMarks();
        }
    }
    
    public double getFinalMark()
    {
        double finalMark = 0;
        for (Marks eachMark : student)
        {
            finalMark += eachMark.getMark() * eachMark.getWeightPercentage();                //Using Loop to calculate final grade for student
        }
        return finalMark;
    }
    
    @Override
    public String toString()
    {
        return "The students name is " + name + "\nThe final Mark is " + getFinalMark();
    }
}
