
import Marks.*;
import java.util.Scanner;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 4shr4
 */
public class Main {
    
    public Main() {
        Scanner scan = new Scanner(System.in);
        
        Marks gradedArray[] = new Marks[4];         //Creating a Marks Array for one student
        
         MarkList students[] = new MarkList[10];        //Creating a MarkList Array for multiple students
         for (int i = 0; i < students.length; i++)
         {
            students[i] = new MarkList();
            students[i].createStudent();                        //Getting the grades and inputs
            System.out.println("Would you like to enter more students? y/n");
            String a = scan.next();
            if (a.equalsIgnoreCase("n"))
            { 
                for (MarkList eachStudent : students) {System.out.println(eachStudent); } return;               //want to break the loop and return results
            }
         }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new Main();
    }
    
}
