
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author 4shr4
 */
public class Main {

    public Main() {
        HashMap<String, ArrayList<Book>> bookMap = new HashMap<String, ArrayList<Book>>();                          //Hashmap
        Scanner scan = new Scanner(System.in);                                                                                                                //Scanner

        System.out.println("Please enter your command"
                + "\nTo Add - Add: Title by: Author Name"
                + "\nTo List - List:"
                + "\nTo Find - Find: authors LastName");
        
        String command = "";
        
        while (!command.equals("end")) {
            command = scan.nextLine();
            String commands[] = command.split(": ");                                        //Commands[0] add, list find --------commands[1] title by, authors lastName----- commands[2]author

            switch (commands[0]) {                                                                      //Case statement to execute particular command
                case "Add": 
                    String book = "";                                       
                    book = commands[1].replaceAll("(by)(?!.*by)", book);                           //String book gets rid of last "by" in String
                    String author[] = commands[2].split(" ");                                                 //author[0] authors firstName--------------------author[1] authors lastName
                    Book addBook = new Book(book, author[0] + " " + author[1]);             //Creates a new book
                    ArrayList<Book> thisOne = bookMap.get(author[1]);                             //ArrayList is set to bookMap.get command to pull existing arraylist
                    if (!bookMap.containsKey(author[1]))                                                        //If there isnt an existing arrayList
                    {
                        thisOne = new ArrayList<Book>();                                                         //Then create an ArrayList
                        bookMap.put(author[1], thisOne);                                                          //Also use (new String(author[1], thisOne)-------------put key and arrayList
                    }
                    thisOne.add(addBook);                                                                               //Add to arrayList
                    System.out.println("Please enter new Command");
                    break;

                case "Find":
                    String author2 = "";
                    author2 = commands[1];                                                                              //author2 String contains authors lastName
                    System.out.println(bookMap.get(author2));                                               //print all books by author using book/map.get to access arraylist inside
                    System.out.println("Please enter new Command");
                    break;

                case "List":
                    Set  keyset = bookMap.keySet();                                                                 //Creating set object assign it to bookMap keys
                    List keyList = new ArrayList(keyset);                                                          //Creating list object based on ArrayList with keyset object passed into it
                    Collections.sort(keyList);                                                                              //Sort keyset using collections.sort method
                    
                    for (Object a : keyset)
                    {
                        System.out.println(bookMap.get(a));                                                     
                    }
                    System.out.println("Please enter new Command");
                    break;
            }
        }
    }
    


    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new Main();
    }

}
