/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment.pkg3;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 *
 * @author Temp
 */
public class Assignment3 extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        Customer objCustomer = new Customer();
        
//Order Button
        Button btnOrder = new Button("Order");
        Button btnExit = new Button("Exit");
        
//List of Toppings
        String toppings[] = new String[] {"salomi", "green peppers", "mushrooms", "olives", "pineapple", "monzarella", "chedder", "tomato", "spinach", "red pepper",
                                            "chilies", "anchovies", "tuna", "sweetcorn", "chicken", "donor" };
        ListView<String> lstToppings = new ListView<>();
        lstToppings.setItems(FXCollections.observableArrayList(toppings));
        lstToppings.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        lstToppings.setId("toppings");
        
        
//Radio Buttons
        ToggleGroup radGroup = new ToggleGroup();
        RadioButton radSize9 = new RadioButton("9");
        RadioButton radSize12 = new RadioButton("12");
        RadioButton radSize16 = new RadioButton("16");
        radSize9.setToggleGroup(radGroup);
        radSize12.setToggleGroup(radGroup);
        radSize16.setToggleGroup(radGroup);
        radSize9.setUserData(9);
        radSize12.setUserData(12);
        radSize16.setUserData(16);
 
//TextBox use getText to get info
        TextField txtName = new TextField();
        TextField txtAddress = new TextField();
        
//CheckBox
        CheckBox chkArea = new CheckBox();
        chkArea.setId("chkArea");
        
//Label spaces indicate next area in vbMain
        Text lblPizza = new Text("getPizza().out");
        lblPizza.setId("pizzalabel");
        
        Label lblName = new Label("Name");
        Label lblAddress = new Label("Address      ");
        
        Label lblPizzaSize = new Label("Please choose what size pizza you would like to order");
        
        Label lblToppings = new Label("Please choose your toppings");
        Label lblCheck = new Label("Check if you live within a 10km radius");
        
//HBox for Name and Address Area
        HBox hbName = new HBox(20);
        hbName.getChildren().add(lblName);
        hbName.getChildren().add(txtName);
        
        HBox hbAddress = new HBox();
        hbAddress.getChildren().add(lblAddress);
        hbAddress.getChildren().add(txtAddress);
        
        HBox hbLayout = new HBox(50);
        hbLayout.getChildren().add(hbName);
        hbLayout.getChildren().add(hbAddress);
        hbLayout.setAlignment(Pos.CENTER);
        
//VBox for lblSize and Radio Button Box for Pizza Size
        HBox hbRadio = new HBox(140);
        hbRadio.getChildren().add(radSize9);
        hbRadio.getChildren().add(radSize12);
        hbRadio.getChildren().add(radSize16);
        
        hbRadio.setAlignment(Pos.CENTER);
        
        VBox vbSizes = new VBox(20);
        vbSizes.getChildren().add(lblPizzaSize);
        vbSizes.getChildren().add(hbRadio);
        vbSizes.setAlignment(Pos.CENTER);
        
//VBox for List toppings and CheckBox free delivery part of HBox hbListCheck
        VBox vbToppings = new VBox(15);
        vbToppings.getChildren().add(lblToppings);
        vbToppings.getChildren().add(lstToppings);
        vbToppings.setAlignment(Pos.TOP_CENTER);
        
        VBox vbCheck = new VBox(15);
        vbCheck.getChildren().add(lblCheck);
        vbCheck.getChildren().add(chkArea);
        vbCheck.setAlignment(Pos.TOP_CENTER);
         
        HBox hbListCheck = new HBox(30);
        hbListCheck.getChildren().add(vbToppings);
        hbListCheck.getChildren().add(vbCheck);
        hbListCheck.setAlignment(Pos.TOP_CENTER);
        
//HBox for buttons
        HBox hbButtons = new HBox(160);
        hbButtons.getChildren().add(btnOrder);
        hbButtons.getChildren().add(btnExit);
        hbButtons.setAlignment(Pos.BOTTOM_CENTER);
        
        
        
//VBox Main
        VBox vbMain = new VBox(50);
        vbMain.getChildren().add(lblPizza);
        vbMain.getChildren().add(hbLayout);
        vbMain.getChildren().add(vbSizes);
        vbMain.getChildren().add(hbListCheck);
        vbMain.getChildren().add(hbButtons);
        vbMain.setAlignment(Pos.TOP_CENTER);                                                                                                                                //setting position to center

        
        btnOrder.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                Alert yourOrder = new Alert(AlertType.INFORMATION);                                                                                                  //Creating Alert setting type
                try {
                objCustomer.setName(txtName.getText());
                objCustomer.setAddress(txtAddress.getText());
                objCustomer.setSize(Integer.parseInt(radGroup.getSelectedToggle().getUserData().toString()));
                objCustomer.setToppings( lstToppings.getSelectionModel().getSelectedItems());
                objCustomer.setFreeDelivery(chkArea.isSelected());                                                                                                       //Up to here method is collected all the info of fields
                
                yourOrder.setTitle("Your Order");                                                                                                                                      //Alert Title
                yourOrder.setContentText(objCustomer.toString());                                                                                                        //The message
                yourOrder.showAndWait();                                                                                                                                                  //need to confirm with OK
                
                txtName.clear(); txtAddress.clear();
                radSize9.setSelected(false);    radSize12.setSelected(false);    radSize16.setSelected(false);
                chkArea.setSelected(false);
                
                //Within first try
                 try {  
                    File file = new File("pizza.txt");
                    PrintWriter writing = new PrintWriter(file);                                                                                                                     //Object used for writing to file
                    writing.println(objCustomer.toString());                                                                                                                        //Calling method to write to file
                    writing.close();                                                                                                                                                                  //exiting object method          
                    lstToppings.getSelectionModel().clearSelection();
                } catch (FileNotFoundException ex) {
                    ex.printStackTrace();                                                                                                                                                        //provide information on errors
                }
                 
                 //Closing first try (the outer one)
                } catch (Exception e) {
                    yourOrder.setContentText("An error has occured information was not provided correctly \n please try again");    //If issues send a message to user
                     yourOrder.showAndWait();
                }
            }
        });
        
        btnExit.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                Platform.exit();                                                                                                                                                                       //Exiting
                System.exit(0);                                                                                                                                                                       //Exiting Again
            }
        });
        
        StackPane root = new StackPane();                                                                                                                                            
        root.getChildren().add(vbMain);                                                                                                                                  //Adding vertical grid with 5 rows shopName, customerName
                                                                                                                                                                                             //PizzaSize, Toppings, Buttons
        
        Scene scene = new Scene(root, 650, 540);                                                                                                                //Size of Form
        scene.getStylesheets().add(Assignment3.class.getResource("myCSS.css").toExternalForm());
        
        primaryStage.setTitle("Welcome to getPizza().out");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
