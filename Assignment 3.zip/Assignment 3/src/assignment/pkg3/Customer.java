/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment.pkg3;

import java.util.List;

public class Customer {
    private String name, address;
    private int size;
    private List <String> toppings;
    private boolean freeDelivery = false;
    
    public Customer() {                                                                                                                                                                           //Constructor to create customer object
        
    }

    //Getters and setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public List<String> getToppings() {
        return toppings;
    }

    public void setToppings(List<String> toppings) {
        this.toppings = toppings;
    }

    public String isFreeDelivery() {
        String a = (this.freeDelivery) ? "is free" : "is not free";
        return a;
    }

    public void setFreeDelivery(boolean freeDelivery) {
        this.freeDelivery = freeDelivery;
    }
    //Everything above getter and setter
    
    
    //special toString with all info
    @Override
    public String toString() {
        return "Thank You for your order " + name + "\t\n Your address is " + address + "\t\nYou have ordered a  "+ size + " inch Pizza containing" + "\t\ntoppings " + toppings + "\t\nYour delivery " + isFreeDelivery();
    }
}
