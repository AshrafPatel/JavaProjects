package com.humber;

import com.humber.model.Employee;

import javax.ejb.Stateless;
import java.util.ArrayList;
import java.util.List;

@Stateless
public class EmployeeService {

    private List<Employee> registeredEmployees;

    public EmployeeService() {
        registeredEmployees = new ArrayList<>();
    }

    public void addEmployee(Employee employeee) {
        registeredEmployees.add(employeee);
    }

    public List<Employee> getRegisteredEmployees() {
        return registeredEmployees;
    }
}
