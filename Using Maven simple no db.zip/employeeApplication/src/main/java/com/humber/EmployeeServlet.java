package com.humber;

import com.humber.model.Department;
import com.humber.model.Employee;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/employees")
public class EmployeeServlet extends HttpServlet {

    @EJB
    private EmployeeService employeeService;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String url = "";
        String validationMessage;
        String empFName = req.getParameter("fName");
        String empLName = req.getParameter("lName");
        String empDepartment = req.getParameter("depo");
        String empAge = req.getParameter("eAge");
        String empSalary = req.getParameter("eSalary");
        if (empFName.isEmpty() || empLName.isEmpty()) {
            validationMessage = "Please specify employee name!";
            req.setAttribute("vMessage", validationMessage);
            url += "/index.jsp";
            getServletContext().getRequestDispatcher(url).forward(req, resp);
        } else if(empDepartment.isEmpty()) {
            validationMessage = "Please specify employee department!";
            req.setAttribute("vMessage", validationMessage);
            url += "/index.jsp";
            getServletContext().getRequestDispatcher(url).forward(req, resp);
        } else if(Integer.valueOf(empAge)< 0) {
            validationMessage = "Please specify a valid employee age!";
            req.setAttribute("vMessage", validationMessage);
            url += "/index.jsp";
            getServletContext().getRequestDispatcher(url).forward(req, resp);
        } else if(Double.valueOf(empSalary) <= 0) {
            validationMessage = "Please specify a valid employee salary!";
            req.setAttribute("vMessage", validationMessage);
            url += "/index.jsp";
            getServletContext().getRequestDispatcher(url).forward(req, resp);
        } else {
            Employee employee = new Employee(empFName, empLName, Department.valueOf(empDepartment), empAge, empSalary);
            employeeService.addEmployee(employee);
            url += "/employeeList.jsp";
            req.setAttribute("employeeList", employeeService.getRegisteredEmployees());
            getServletContext().getRequestDispatcher(url).forward(req, resp);
        }
    }
}
