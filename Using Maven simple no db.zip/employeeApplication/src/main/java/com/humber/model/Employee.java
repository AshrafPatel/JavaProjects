package com.humber.model;

public class Employee {
    String FName;
    String lName;
    Department depo;
    String age;
    String salary;

    public Employee(String FName, String lName, Department depo, String age, String salary) {
        this.FName = FName;
        this.lName = lName;
        this.depo = depo;
        this.age = age;
        this.salary = salary;
    }

    public String getFName() {
        return FName;
    }

    public void setFName(String FName) {
        this.FName = FName;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }

    public Department getDepo() {
        return depo;
    }

    public void setDepo(Department depo) {
        this.depo = depo;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getSalary() {
        return salary;
    }

    public void setSalary(String slary) {
        this.salary = slary;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "depo=" + depo +
                ", FName='" + FName + '\'' +
                ", lName='" + lName + '\'' +
                ", age=" + age +
                ", salary=" + salary +
                '}';
    }
}
