package com.humber.model;

public enum Department {
    MARKETING, IT, SALES;
}
